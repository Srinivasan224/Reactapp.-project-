import React from 'react'

const NewsPage = () => {
  return (
    <div>NewsPage</div>
  )
}

export default NewsPage